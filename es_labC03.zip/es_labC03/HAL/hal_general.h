#ifndef _HAL_GENERAL_H_
#define _HAL_GENERAL_H_

extern void HAL_Init(void);

#endif
