#ifndef _HAL_UCS_H_
#define _HAL_UCS_H_

void HAL_UCS_Init();

#define XTAL_FREQU 20000000
#define MCLK_FREQU 20000000
#define SMCLK_FREQU 2500000

#endif
