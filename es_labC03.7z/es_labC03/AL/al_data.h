#ifndef _AL_DATA_H_
#define _AL_DATA_H_

#define TABLE_SIZE 512

extern const unsigned short ir_front[TABLE_SIZE];
extern const unsigned short ir_right[TABLE_SIZE];
extern const unsigned short ir_left[TABLE_SIZE];

void AL_SensorDistances();

#endif
