#ifndef _DRIVER_GENERAL_H_
#define _DRIVER_GENERAL_H_


void Driver_Init();

#endif
