#ifndef _HAL_WDT_H_
#define _HAL_WDT_H_

extern void HAL_Wdt_Init(void);

#endif
