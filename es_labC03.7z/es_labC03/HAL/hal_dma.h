#ifndef _HAL_DMA_H_
#define _HAL_DMA_H_

void HAL_DMA_Init(void);

#endif
